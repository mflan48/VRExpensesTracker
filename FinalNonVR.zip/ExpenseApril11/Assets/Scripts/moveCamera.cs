﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCamera : MonoBehaviour {

    private float moveSpeed = 0.05f;
    private float rotateSpeed = 2.0f;

    private float yaw = 0.0f;
    private float pitch = 0.0f;



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {



        if (!Input.GetKey(KeyCode.LeftControl))
        {
            rotateCamera();
        }
        if (GameObject.Find("MainCamera").GetComponent<createColMoney>().isEditingColumn == false)
        {
            moveMyCamera();
        }


    }


    //Move the camera 
    private void moveMyCamera()
    {
   
        
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Translate(Vector3.left * moveSpeed, Space.World);
        }
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            transform.Translate(Vector3.right * moveSpeed, Space.World);
        }

        
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            transform.Translate(Vector3.forward * moveSpeed,Space.World);
        }
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            transform.Translate(Vector3.back * moveSpeed,Space.World);
        }
        

    }
    
    //Rotate the camera
    private void rotateCamera()
    {
        yaw += rotateSpeed * Input.GetAxis("Mouse X");
        pitch -= rotateSpeed * Input.GetAxis("Mouse Y");
        transform.eulerAngles = new Vector3(pitch, yaw, 0.0f);
    }
}
