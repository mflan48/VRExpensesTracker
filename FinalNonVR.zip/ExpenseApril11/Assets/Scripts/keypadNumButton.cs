﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class keypadNumButton : MonoBehaviour {

    static bool toRend = true;


    private Vector3 appearOnScreenLoc;
    private Vector3 appearOffScreenLoc;

    //This is the "id" of the button. Each button has a hardcoded value
    public string myID;

    //Static string between all buttons. This is what is displayed in the gameObject "displayNumber"
    static string toDisplay = "";

    private void Start()
    {
        // renderOutView();
        appearOnScreenLoc = GameObject.Find("MainCamera").transform.position;
        //appearOnScreenLoc.y += 3f;
        appearOnScreenLoc.z += .5f;


        appearOffScreenLoc = GameObject.Find("MainCamera").transform.position;
        appearOffScreenLoc.z += .5f;
        appearOffScreenLoc.y += 3f;

    }


    void upOff()
    {
        appearOffScreenLoc = GameObject.Find("MainCamera").transform.position;
        appearOffScreenLoc.y += 3f;
        appearOffScreenLoc.z += .5f;
    }
    void upOn()
    {
        appearOnScreenLoc = GameObject.Find("MainCamera").transform.position;
        appearOnScreenLoc.z += .5f;
    }



    void Update()
    {
        upOff();
        upOn();
        if(GameObject.Find("MainCamera").GetComponent<createColMoney>().isEditingColumn == true)
        {
            renderIntoView();
            checkButtonClicked();
            displayText();
            print(toDisplay);
        }

    }

    void renderOutView()
    {
        //GameObject.Find("displayNumber").GetComponent<TextMesh>().text = "";

        if (toRend == false)
        {
            toRend = true;
            GameObject.Find("myKeypad").transform.position = appearOffScreenLoc;
            GameObject.Find("myKeypad").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button0").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button1").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button2").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button3").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button4").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button5").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button6").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button7").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button8").GetComponent<Renderer>().enabled = false;
            GameObject.Find("Button9").GetComponent<Renderer>().enabled = false;
            GameObject.Find("ButtonE").GetComponent<Renderer>().enabled = false;
            GameObject.Find("ButtonC").GetComponent<Renderer>().enabled = false;
        }

        
    }
    
     void renderIntoView()
    {
            if(toRend == true)
            {
                toRend = false;
            GameObject.Find("myKeypad").transform.position = appearOnScreenLoc;
            GameObject.Find("myKeypad").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button0").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button1").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button2").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button3").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button4").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button5").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button6").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button7").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button8").GetComponent<Renderer>().enabled = true;
            GameObject.Find("Button9").GetComponent<Renderer>().enabled = true;
            GameObject.Find("ButtonE").GetComponent<Renderer>().enabled = true;
            GameObject.Find("ButtonC").GetComponent<Renderer>().enabled = true;
        }
            

            

    }
    
    //Display the text to the keypadScreen
    void displayText()
    {
        //SHIT CODE but if theres an error just catch anything
        try
        {
            GameObject.Find("displayNumber").GetComponent<TextMesh>().text = toDisplay;
        }
        catch
        {
            print("error finding the displayNumberObject");
        }
    }


    //Update the display with the numbers
    void updateDisplayWithID()
    {
        toDisplay += myID;
    }


    //Enter the number into the display
    /*
     * This should take the current string value of toDisplay and send it to the curSelectedObject
     * That has a function to take in a string of the selected amount and update the size accordingly
     * This will also force the user to leave the keyPad display menu 
    */
    void EnterDisplayAndExitKeyPad()
    {
        //FUNCTION THAT WILL RETURN THE STRING TO THE curSelectedObject

        //get the curSelectedObject()
        Transform myCurSelect = null;
        try
        {
            myCurSelect=GameObject.Find("MainCamera").GetComponent<createColMoney>().getCurSelectedObject();

        }
        catch
        {
            print("Error trying to find curSelectedObject");
        }

        if(myCurSelect != null)
        {
            print("inmypants");
            //Set the curSelectedObject amount to the display
            myCurSelect.GetComponent<colMoney>().setNumDollars(float.Parse(toDisplay));
            myCurSelect.GetComponent<colMoney>().updateSize();
        }


        
        //Reset the display
        toDisplay = "";
        //toRend = true;
        renderOutView();
        

        //Function that exits keypad
        GameObject.Find("MainCamera").GetComponent<createColMoney>().isEditingColumn = false;
    }


    //This should just clear the Display and allow the user to stay in the keypad menu
    void ClearDisplayAndRemainKeyPad()
    {
        toDisplay = "";
    }

    void checkButtonClicked()
    {
        //Check if the object was selected and print its value to the string
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                string toCheckNum = "Button";
                toCheckNum += myID.ToString();
                //Check if any button was hit
                if (hit.transform.name == toCheckNum)
                {
                    if (toCheckNum == "ButtonC")
                    {
                        //Clear button is pressed
                        ClearDisplayAndRemainKeyPad();
                    }
                    else if (toCheckNum == "ButtonE")
                    {
                        //Enter button is pressed
                        EnterDisplayAndExitKeyPad();
                    }
                    else
                    {
                        //A number is pressed
                        updateDisplayWithID();
                    }

                }
            }
        }
    }

}
