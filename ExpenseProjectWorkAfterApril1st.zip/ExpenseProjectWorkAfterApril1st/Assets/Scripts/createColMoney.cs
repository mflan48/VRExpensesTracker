﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;





public class createColMoney : MonoBehaviour {

    //Custom prefab that we use to create colMoney type objects
    public Transform custColMoneyPrefab;

    //List to hold all of the prefabs
    private List<Transform> colMoneyList;

    //Object to get track of which object is selected
    private Transform curSelectedObject;


    //money material
    public Material myMoneyColor;


    // Use this for initialization
    void Start () {

        //Initialize to empty list
        colMoneyList = new List<Transform>();
        curSelectedObject = null;
	}
	
	// Update is called once per frame
	void Update () {


        //Get the current mode
        string curMode = GameObject.Find("MainCamera").GetComponent<selectMode>().getCurrentMode();

        //Check if we are in create mode
        if(curMode == "CreateModeText")
        {
            runCreateModeCode();
        }

        //Do stuff with 
        if(curMode == "EditModeText")
        {
            runEditModeCode();
        }

        if(curMode == "DeleteModeText")
        {

        }

        
		
	}


    //This method will be used to run everything related to being in create Mode
    void runCreateModeCode()
    {
        // print("InCreateColMoney.cs and in createMode");e


        //If the user presses Space, create a new instance of colMoney Prefab and add it to our list of colMoneys
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Create the vector as to where to place the cube
            Vector3 curCameraLoc = new Vector3(Camera.main.gameObject.transform.position.x, Camera.main.gameObject.transform.position.y + .5f, Camera.main.gameObject.transform.position.z + 2f);
            // print("Trying to add new colMoneyObject");


            //Create the object and add it to our list of colMoney
            Transform temp = Instantiate(custColMoneyPrefab, curCameraLoc, Quaternion.identity);
            colMoneyList.Add(temp);
        }
    }


    void runEditModeCode()
    {
        selectObject();
    }


    //Update the colors of all the items in our colMoney List. The selectedObjectColor will be red selectedColor and all the others will be the moneymaterial
    void highlightObjects(Color selectedColor, Material unselectedColor)
    {
        foreach(Transform curTrans in colMoneyList)
        {
            if(curSelectedObject != null && curSelectedObject == curTrans)
            {
                curTrans.GetComponent<colMoney>().updateColor(selectedColor);
            }else if(curSelectedObject != null)
            {
                curTrans.GetComponent<colMoney>().updateColor(unselectedColor);
            }
        }

    }


    void selectObject()
    {
        //Detect if we clicked on any object
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                int IDObjselected;
                
                //Try to select an object by seeing if what the user clicked on is a colMoneyObject with an ID
                try
                {
                    IDObjselected = hit.transform.GetComponent<colMoney>().getMyID();

                    //Set the curSelectedObject to the one we selected
                    curSelectedObject = getColMoneyWithIDNUM(IDObjselected);

                    //Update the hightlighter objects
                    highlightObjects(Color.red, myMoneyColor);
                }
                catch//No Object was selected so dont do anything
                {
                    print("Error: No ColMoneyObjectSelected");
                }


            }
        }
    }


    void printColMoneyList()
    {
        foreach(Transform x in colMoneyList)
        {
            print(x.GetComponent<colMoney>().getMyID());
        }
    }


    public List<Transform> getColMoneyList()
    {
        return (colMoneyList);
    }




    //Return the colMoneyGameObejct that has the IDNUM
    private Transform getColMoneyWithIDNUM(int IDNUM)
    {
        foreach(Transform curObject in colMoneyList)
        {
            if(curObject.GetComponent<colMoney>().getMyID() == IDNUM)
            {
                return (curObject);
            }
        }

        return (null);

    }
}
