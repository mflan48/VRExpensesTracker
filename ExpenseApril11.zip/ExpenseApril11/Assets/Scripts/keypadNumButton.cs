﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class keypadNumButton : MonoBehaviour {



    //This is the "id" of the button. Each button has a hardcoded value
    public string myID;

    //Static string between all buttons. This is what is displayed in the gameObject "displayNumber"
    static string toDisplay = "";



    void Update()
    {
        checkButtonClicked();
        displayText();
    }

    //Display the text to the keypadScreen
    void displayText()
    {
        //SHIT CODE but if theres an error just catch anything
        try
        {
            GameObject.Find("displayNumber").GetComponent<TextMesh>().text = toDisplay;
        }
        catch
        {
            print("error finding the displayNumberObject");
        }
    }


    //Update the display with the numbers
    void updateDisplayWithID()
    {
        toDisplay += myID;
    }


    //Enter the number into the display
    /*
     * This should take the current string value of toDisplay and send it to the curSelectedObject
     * That has a function to take in a string of the selected amount and update the size accordingly
     * This will also force the user to leave the keyPad display menu 
    */
    void EnterDisplayAndExitKeyPad()
    {
        //FUNCTION THAT WILL RETURN THE STRING TO THE curSelectedObject

        //get the curSelectedObject()
        Transform myCurSelect = null;
        try
        {
            myCurSelect=GameObject.Find("MainCamera").GetComponent<createColMoney>().getCurSelectedObject();

        }
        catch
        {
            print("Error trying to find curSelectedObject");
        }

        if(myCurSelect != null)
        {
            print("inmypants");
            //Set the curSelectedObject amount to the display
            myCurSelect.GetComponent<colMoney>().setNumDollars(float.Parse(toDisplay));
            myCurSelect.GetComponent<colMoney>().updateSize();
        }


        
        //Reset the display
        toDisplay = "";

        //Function that exits keypad
    }


    //This should just clear the Display and allow the user to stay in the keypad menu
    void ClearDisplayAndRemainKeyPad()
    {
        toDisplay = "";
    }

    void checkButtonClicked()
    {
        //Check if the object was selected and print its value to the string
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                string toCheckNum = "Button";
                toCheckNum += myID.ToString();
                //Check if any button was hit
                if (hit.transform.name == toCheckNum)
                {
                    if (toCheckNum == "ButtonC")
                    {
                        //Clear button is pressed
                        ClearDisplayAndRemainKeyPad();
                    }
                    else if (toCheckNum == "ButtonE")
                    {
                        //Enter button is pressed
                        EnterDisplayAndExitKeyPad();
                    }
                    else
                    {
                        //A number is pressed
                        updateDisplayWithID();
                    }

                }
            }
        }
    }

}
