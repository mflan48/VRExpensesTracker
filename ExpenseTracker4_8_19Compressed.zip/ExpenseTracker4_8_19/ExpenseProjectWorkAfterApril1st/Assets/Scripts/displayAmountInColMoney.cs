﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class displayAmountInColMoney : MonoBehaviour {



	// Use this for initialization
	void Start () {


	}
	
	// Update is called once per frame
	void Update () {

        if(transform.parent != null)
        {
            this.GetComponent<TextMesh>().text = "Amount = " + transform.parent.GetComponent<colMoney>().getNumDollars().ToString();
            Vector3 temp = transform.parent.GetComponent<colMoney>().transform.position;
            
            temp.z -= .1f;
            //print(temp);
            
            this.transform.position = temp;
        }
        else
        {
            Destroy(this);
        }
    }
        
}
