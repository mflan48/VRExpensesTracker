﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colMoney : MonoBehaviour {

    //used to create a unique ID for each block we create
    static int ID = 0;

    //Float to keep track of how big the cube is. this will be used in the edit mode
    private float numDollars;
    private int myID;

    //Coordinates of the cube. will be used in the edit mode
    private Vector3 coordinates;

	// Use this for initialization
	void Start () {

        //Set the ID of this specific colMoney to ID and increment the ID
        ID += 1;
        myID = ID;
        

        //default num of dollars i 10
        numDollars = 10f;
        
        //Set the defaulut coordinates of this colMeny to right in front of the person
        coordinates = new Vector3(Camera.main.gameObject.transform.position.x, Camera.main.gameObject.transform.position.y, Camera.main.gameObject.transform.position.z);

	}
	
	// Update is called once per frame
	void Update () {
        updateCoordinates();
        updateSize();
	}


    //Function to be called in edit mode
    void updateCoordinates()
    {

    }

    //Function to be called in edit mode
    void updateSize()
    {

    }






    public int getMyID()
    {
        return (myID);
    }
}
