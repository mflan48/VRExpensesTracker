﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;





public class createColMoney : MonoBehaviour {

    //Custom prefab that we use to create colMoney type objects
    public Transform custColMoneyPrefab;

    //List to hold all of the prefabs
    private List<Transform> colMoneyList;


    // Use this for initialization
    void Start () {

        //Initialize to empty list
        colMoneyList = new List<Transform>();
	}
	
	// Update is called once per frame
	void Update () {


        //Get the current mode
        string curMode = GameObject.Find("MainCamera").GetComponent<selectMode>().getCurrentMode();

        //Check if we are in create mode
        if(curMode == "CreateModeText")
        {
           // print("InCreateColMoney.cs and in createMode");
            if (Input.GetKeyDown(KeyCode.Space))
            {
                //Create the vector as to where to place the cube
                Vector3 curCameraLoc = new Vector3(Camera.main.gameObject.transform.position.x +1f, Camera.main.gameObject.transform.position.y, Camera.main.gameObject.transform.position.z + 2f);
                // print("Trying to add new colMoneyObject");


                //Create the object and add it to our list of colMoney
                Transform temp = Instantiate(custColMoneyPrefab, curCameraLoc, Quaternion.identity);
                colMoneyList.Add(temp);
            }
        }

        //Do stuff with 
        if(curMode == "EditModeText")
        {

        }

        if(curMode == "DeleteModeText")
        {

        }

        
		
	}



    void printColMoneyList()
    {
        foreach(Transform x in colMoneyList)
        {
            print(x.GetComponent<colMoney>().getMyID());
        }
    }


    public List<Transform> getColMoneyList()
    {
        return (colMoneyList);
    }
}
