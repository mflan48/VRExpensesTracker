﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;





public class createColMoney : MonoBehaviour {

    //prefab used to display the money in a col
    public Transform displayColMoney;

    //Custom prefab that we use to create colMoney type objects
    public Transform custColMoneyPrefab;

    //List to hold all of the prefabs
    private List<Transform> colMoneyList;

    private List<Transform> displayColMoneyList;

    //Object to get track of which object is selected
    private Transform curSelectedObject;

    private bool isMovingColMoney = false;


    //money material
    public Material myMoneyColor;




    // Use this for initialization
    void Start () {

        //Initialize to empty list
        colMoneyList = new List<Transform>();
        curSelectedObject = null;
        displayColMoneyList = new List<Transform>();

	}
	
	// Update is called once per frame
	void Update () {


        //Get the current mode
        string curMode = GameObject.Find("MainCamera").GetComponent<selectMode>().getCurrentMode();

        //Check if we are in create mode
        if(curMode == "CreateModeText")
        {
            runCreateModeCode();
            highlightObjects(myMoneyColor.color, myMoneyColor);
        }else if(curMode == "EditModeText")
        {
            runEditModeCode();
        }else if(curMode == "DeleteModeText")
        {
            runDeleteMode();
        }

        
		
	}


    //This method will be used to run everything related to being in create Mode
    void runCreateModeCode()
    {
        // print("InCreateColMoney.cs and in createMode");e


        //If the user presses Space, create a new instance of colMoney Prefab and add it to our list of colMoneys
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Create the vector as to where to place the cube
            Vector3 curCameraLoc = new Vector3(Camera.main.gameObject.transform.position.x, Camera.main.gameObject.transform.position.y + .5f, Camera.main.gameObject.transform.position.z + 1f);
            // print("Trying to add new colMoneyObject");


            //Create the object and add it to our list of colMoney

            
            //Create the colMoneyPrefab
            Transform temp = Instantiate(custColMoneyPrefab, curCameraLoc, Quaternion.identity);

            //Create the display to go with it and set its parent to the newly created prefab
            Transform tempDisplay = Instantiate(displayColMoney);
            tempDisplay.parent = temp;
            //tempDisplay.GetComponent<displayAmountInColMoney>().colMoneyConnectedTo = temp;

            colMoneyList.Add(temp);
            displayColMoneyList.Add(tempDisplay);
        }
    }


    private void runEditModeCode()
    {
         selectObject();
         moveColMoney();

    }




    private void runDeleteMode()
    {
        if(curSelectedObject != null)
        {
            if(!isMovingColMoney &&  Input.GetKeyDown(KeyCode.Space))
            {
                print("CockSucker");
                colMoneyList.Remove(curSelectedObject);
                
                Destroy(curSelectedObject.gameObject);
                curSelectedObject = null;
            }
            
        }
    }


    private void moveColMoney()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            isMovingColMoney = !isMovingColMoney;
        }

        if(isMovingColMoney && curSelectedObject != null)
        {

            Vector3 temp = Camera.main.transform.position;
            temp.y += .05f;
            temp.z += .5f;
            curSelectedObject.GetComponent<colMoney>().setCoordinates(temp);
        }

    }






    //Update the colors of all the items in our colMoney List. The selectedObjectColor will be red selectedColor and all the others will be the moneymaterial
    private void highlightObjects(Color selectedColor, Material unselectedColor)
    {
        foreach(Transform curTrans in colMoneyList)
        {
            if(curSelectedObject != null && curSelectedObject == curTrans)
            {
                curTrans.GetComponent<colMoney>().updateColor(selectedColor);
            }else if(curSelectedObject != null)
            {
                curTrans.GetComponent<colMoney>().updateColor(unselectedColor);
            }
        }

    }


    private void selectObject()
    {


        if(!isMovingColMoney)
        {
            //Detect if we clicked on any object
            if (Input.GetMouseButtonDown(0))
            {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

                if (Physics.Raycast(ray, out hit))
                {
                    int IDObjselected;

                    //Try to select an object by seeing if what the user clicked on is a colMoneyObject with an ID
                    try
                    {
                        IDObjselected = hit.transform.GetComponent<colMoney>().getMyID();

                        //Set the curSelectedObject to the one we selected
                        curSelectedObject = getColMoneyWithIDNUM(IDObjselected);


                        //Update the hightlighter objects
                        highlightObjects(Color.red, myMoneyColor);
                    }
                    catch//No Object was selected so dont do anything
                    {
                        print("Error: No ColMoneyObjectSelected");
                    }


                }
            }
        }
       
    }


    void printColMoneyList()
    {
        foreach(Transform x in colMoneyList)
        {
            print(x.GetComponent<colMoney>().getMyID());
        }
    }


    public List<Transform> getColMoneyList()
    {
        return (colMoneyList);
    }




    //Return the colMoneyGameObejct that has the IDNUM
    private Transform getColMoneyWithIDNUM(int IDNUM)
    {
        foreach(Transform curObject in colMoneyList)
        {
            if(curObject.GetComponent<colMoney>().getMyID() == IDNUM)
            {
                return (curObject);
            }
        }

        return (null);

    }
}
