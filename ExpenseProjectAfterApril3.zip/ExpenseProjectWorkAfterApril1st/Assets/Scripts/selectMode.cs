﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class selectMode : MonoBehaviour {


    private string currentMode;
    private List<string> typeModes;
	// Use this for initialization
	void Start () {

        typeModes = new List<string>();
        typeModes.Add("CreateModeText");
        typeModes.Add("EditModeText");
        typeModes.Add("DeleteModeText");
		
	}
	
	// Update is called once per frame
	void Update () {
        checkCurrentMode();
        updateCurrentMode();
        
	}

    void updateCurrentMode()
    {
        //Make all the non selected nodes white
        //Make the selected node Green
        if(currentMode != "")
        {
            foreach (string mode in typeModes)
            {
                if(mode != currentMode)
                {
                    GameObject.Find(mode).GetComponent<Renderer>().material.SetColor("_Color", Color.white);
                }
                else
                {
                    GameObject.Find(mode).GetComponent<Renderer>().material.SetColor("_Color", Color.green);
                }
            }
        }
        
    }

    void checkCurrentMode()
    {
        if(Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if(Physics.Raycast(ray, out hit))
            {
                //if we are in create mode, set the currentMode var to createModeText
                if(hit.transform.name == "CreateModeText")
                {
                    currentMode = "CreateModeText";
                    print("Setting Mode to createMode");
                }

                //Update currentMode to editmodetext
                if(hit.transform.name == "EditModeText")
                {
                    currentMode = "EditModeText";
                    print("Setting Mode to EditMode");
                }

                //update currentmode to deletemodetext
                if(hit.transform.name == "DeleteModeText")
                {
                    currentMode = "DeleteModeText";
                    print("Setting Mode to deleteMode");
                }
            }
        }
    }




    public string getCurrentMode()
    {
        return (currentMode);
    }

    public List<string> getTypeModes()
    {
        return (typeModes);
    }
}
